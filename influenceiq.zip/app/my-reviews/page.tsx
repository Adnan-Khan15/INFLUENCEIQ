import { getServerSession } from "next-auth/next"
import { redirect } from "next/navigation"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

import { authOptions } from "@/lib/auth"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AuthButton } from "@/components/auth-button"
import { UserReviewsList } from "@/components/user-reviews-list"

export default async function MyReviewsPage() {
  const session = await getServerSession(authOptions)

  if (!session) {
    redirect("/auth?callbackUrl=/my-reviews")
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center">
          <Link href="/" className="flex items-center gap-2 font-bold text-xl">
            <span className="text-primary">Influence</span>
            <span>IQ</span>
          </Link>
          <div className="flex flex-1 items-center justify-end space-x-4">
            <AuthButton />
          </div>
        </div>
      </header>

      <main className="flex-1 container py-10">
        <Link href="/" className="flex items-center text-sm mb-6 hover:underline">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Home
        </Link>

        <h1 className="text-3xl font-bold mb-6">My Reviews</h1>

        <Card>
          <CardHeader>
            <CardTitle>Reviews You've Written</CardTitle>
          </CardHeader>
          <CardContent>
            <UserReviewsList userId={session.user.id} />
          </CardContent>
        </Card>
      </main>

      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} InfluenceIQ. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <Link href="https://github.com/Adnan-Khan15" className="text-sm text-muted-foreground underline">
              About
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

