import { Suspense } from "react"
import Link from "next/link"
import { Filter, Search, SlidersHorizontal } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Skeleton } from "@/components/ui/skeleton"
import { CelebrityCard } from "@/components/celebrity-card"
import { AuthButton } from "@/components/auth-button"

async function searchCelebrities(query: string) {
  const res = await fetch(`${process.env.NEXT_PUBLIC_APP_URL || ""}/api/celebrities?q=${encodeURIComponent(query)}`, {
    cache: "no-store",
  })

  if (!res.ok) {
    throw new Error("Failed to search celebrities")
  }

  return res.json()
}

export default function SearchPage({ searchParams }: { searchParams: { q?: string } }) {
  const query = searchParams.q || ""

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center">
          <Link href="/" className="flex items-center gap-2 font-bold text-xl">
            <span className="text-primary">Influence</span>
            <span>IQ</span>
          </Link>
          <div className="flex flex-1 items-center justify-end space-x-4">
            <div className="relative w-full max-w-sm">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <form action="/search">
                <Input
                  type="search"
                  name="q"
                  placeholder="Search celebrities..."
                  className="w-full pl-8"
                  defaultValue={query}
                />
              </form>
            </div>
            <AuthButton />
          </div>
        </div>
      </header>

      <main className="flex-1 container py-10">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">{query ? `Search Results for "${query}"` : "Browse Celebrities"}</h1>
          <Button variant="outline" size="sm" className="lg:hidden">
            <Filter className="h-4 w-4 mr-2" />
            Filters
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <div className="hidden lg:block">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold">Filters</h2>
                  <Button variant="ghost" size="sm" className="h-8 text-xs">
                    Reset
                  </Button>
                </div>

                <div className="space-y-6">
                  <div>
                    <h3 className="font-medium mb-3">Industry</h3>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox id="industry-tech" />
                        <label htmlFor="industry-tech" className="text-sm">
                          Technology
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="industry-entertainment" />
                        <label htmlFor="industry-entertainment" className="text-sm">
                          Entertainment
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="industry-sports" />
                        <label htmlFor="industry-sports" className="text-sm">
                          Sports
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="industry-business" />
                        <label htmlFor="industry-business" className="text-sm">
                          Business
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="industry-politics" />
                        <label htmlFor="industry-politics" className="text-sm">
                          Politics
                        </label>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-medium mb-3">Score Range</h3>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox id="score-9-10" />
                        <label htmlFor="score-9-10" className="text-sm">
                          9.0 - 10.0
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="score-8-9" />
                        <label htmlFor="score-8-9" className="text-sm">
                          8.0 - 8.9
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="score-7-8" />
                        <label htmlFor="score-7-8" className="text-sm">
                          7.0 - 7.9
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="score-below-7" />
                        <label htmlFor="score-below-7" className="text-sm">
                          Below 7.0
                        </label>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-medium mb-3">Region</h3>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox id="region-north-america" />
                        <label htmlFor="region-north-america" className="text-sm">
                          North America
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="region-europe" />
                        <label htmlFor="region-europe" className="text-sm">
                          Europe
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="region-asia" />
                        <label htmlFor="region-asia" className="text-sm">
                          Asia
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="region-other" />
                        <label htmlFor="region-other" className="text-sm">
                          Other
                        </label>
                      </div>
                    </div>
                  </div>

                  <Button className="w-full">Apply Filters</Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-3">
            <div className="flex justify-between items-center mb-6">
              <p className="text-muted-foreground">
                {query ? `Showing results for "${query}"` : "Showing all celebrities"}
              </p>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" className="flex items-center gap-1">
                  <SlidersHorizontal className="h-4 w-4" />
                  <span>Sort</span>
                </Button>
              </div>
            </div>

            <Suspense fallback={<SearchResultsSkeleton />}>
              <SearchResults query={query} />
            </Suspense>
          </div>
        </div>
      </main>

      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} InfluenceIQ. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <Link href="https://github.com/Adnan-Khan15" className="text-sm text-muted-foreground underline">
              About
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

function SearchResultsSkeleton() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {Array(6)
        .fill(0)
        .map((_, i) => (
          <Card key={i} className="overflow-hidden">
            <CardContent className="p-0">
              <div className="flex flex-col">
                <Skeleton className="h-48 w-full" />
                <div className="p-4">
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-full mb-4" />
                  <div className="flex justify-between">
                    <Skeleton className="h-8 w-24" />
                    <Skeleton className="h-8 w-24" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
    </div>
  )
}

async function SearchResults({ query }: { query: string }) {
  const results = await searchCelebrities(query)

  if (results.length === 0) {
    return (
      <div className="text-center py-12">
        <h2 className="text-xl font-semibold mb-2">No results found</h2>
        <p className="text-muted-foreground">Try adjusting your search or filters to find what you're looking for.</p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {results.map((celebrity: any) => (
        <CelebrityCard key={celebrity.id} celebrity={celebrity} />
      ))}
    </div>
  )
}

