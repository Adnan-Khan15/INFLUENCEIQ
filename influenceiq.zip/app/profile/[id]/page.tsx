import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, BarChart2, Heart, TrendingUp, User } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PopularityChart } from "@/components/popularity-chart"
import { SentimentBreakdown } from "@/components/sentiment-breakdown"
import { RecentActivity } from "@/components/recent-activity"
import { UserReviews } from "@/components/user-reviews"
import { AuthButton } from "@/components/auth-button"

async function getCelebrity(id: string) {
  const res = await fetch(`${process.env.NEXT_PUBLIC_APP_URL || ""}/api/celebrities/${id}`, {
    cache: "no-store",
  })

  if (!res.ok) {
    throw new Error("Failed to fetch celebrity")
  }

  return res.json()
}

export default async function ProfilePage({ params }: { params: { id: string } }) {
  const celebrity = await getCelebrity(params.id)

  if (!celebrity) {
    return <div>Celebrity not found</div>
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center">
          <Link href="/" className="flex items-center gap-2 font-bold text-xl">
            <span className="text-primary">Influence</span>
            <span>IQ</span>
          </Link>
          <div className="flex flex-1 items-center justify-end space-x-4">
            <AuthButton />
          </div>
        </div>
      </header>

      <main className="flex-1 container py-10">
        <Link href="/" className="flex items-center text-sm mb-6 hover:underline">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Home
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col items-center">
                  <div className="relative w-48 h-48 rounded-full overflow-hidden mb-4">
                    <Image
                      src={celebrity.image || "/placeholder.svg"}
                      alt={celebrity.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <h1 className="text-2xl font-bold mb-1">{celebrity.name}</h1>
                  {celebrity.age && <p className="text-muted-foreground mb-4">Age: {celebrity.age}</p>}
                  <p className="text-center mb-6">{celebrity.description}</p>

                  <div className="grid grid-cols-2 gap-4 w-full">
                    <Card>
                      <CardContent className="p-4 flex flex-col items-center">
                        <BarChart2 className="h-5 w-5 text-primary mb-2" />
                        <p className="text-sm text-muted-foreground">Popularity</p>
                        <p className="text-xl font-bold">{celebrity.popularityScore.toFixed(1)}</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4 flex flex-col items-center">
                        <Heart className="h-5 w-5 text-primary mb-2" />
                        <p className="text-sm text-muted-foreground">Sentiment</p>
                        <p className="text-xl font-bold">{celebrity.sentimentScore.toFixed(1)}</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4 flex flex-col items-center">
                        <User className="h-5 w-5 text-primary mb-2" />
                        <p className="text-sm text-muted-foreground">Credibility</p>
                        <p className="text-xl font-bold">{celebrity.credibilityScore.toFixed(1)}</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4 flex flex-col items-center">
                        <TrendingUp className="h-5 w-5 text-primary mb-2" />
                        <p className="text-sm text-muted-foreground">Engagement</p>
                        <p className="text-xl font-bold">{celebrity.engagementScore.toFixed(1)}</p>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-2">
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="mb-4">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="activity">Recent Activity</TabsTrigger>
                <TabsTrigger value="reviews">User Reviews</TabsTrigger>
              </TabsList>

              <TabsContent value="overview">
                <div className="grid grid-cols-1 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Popularity Trend</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <PopularityChart celebrityId={celebrity.id} />
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Sentiment Breakdown</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <SentimentBreakdown
                        credibility={celebrity.credibilityScore}
                        engagement={celebrity.engagementScore}
                        sentiment={celebrity.sentimentScore}
                      />
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="activity">
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Activity</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <RecentActivity activity={celebrity.recentActivity || []} />
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="reviews">
                <Card>
                  <CardHeader>
                    <CardTitle>User Reviews</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <UserReviews celebrityId={celebrity.id} />
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>

      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} InfluenceIQ. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <Link href="https://github.com/Adnan-Khan15" className="text-sm text-muted-foreground underline">
              About
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

