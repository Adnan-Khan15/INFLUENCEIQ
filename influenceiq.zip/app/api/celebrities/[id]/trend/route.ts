import { NextResponse } from "next/server"
import { getPopularityTrend } from "@/lib/api"
import clientPromise from "@/lib/mongodb"
import { ObjectId } from "mongodb"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id

    // First try to find by MongoDB ID
    try {
      const client = await clientPromise
      const db = client.db()

      const celebrity = await db.collection("celebrities").findOne({ _id: new ObjectId(id) })

      if (celebrity) {
        const trendData = await getPopularityTrend(celebrity.name)
        return NextResponse.json(trendData)
      }
    } catch (mongoError) {
      // If not a valid MongoDB ID, try to decode as a name
      console.error("Not a valid MongoDB ID, trying as name:", mongoError)
    }

    // If not found by ID, try to fetch by name
    try {
      // Assume ID might be a base64 encoded name
      const name = Buffer.from(id, "base64").toString()
      const trendData = await getPopularityTrend(name)
      return NextResponse.json(trendData)
    } catch (nameError) {
      console.error("Error fetching trend by name:", nameError)
      return NextResponse.json({ error: "Celebrity not found" }, { status: 404 })
    }
  } catch (error) {
    console.error("Error fetching trend data:", error)
    return NextResponse.json({ error: "Failed to fetch trend data" }, { status: 500 })
  }
}

