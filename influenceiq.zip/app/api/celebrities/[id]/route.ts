import { NextResponse } from "next/server"
import { fetchCelebrityProfile } from "@/lib/api"
import clientPromise from "@/lib/mongodb"
import { ObjectId } from "mongodb"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id

    // First try to find by MongoDB ID
    try {
      const client = await clientPromise
      const db = client.db()

      const celebrity = await db.collection("celebrities").findOne({ _id: new ObjectId(id) })

      if (celebrity) {
        return NextResponse.json({
          id: celebrity._id.toString(),
          name: celebrity.name,
          image: celebrity.image,
          age: celebrity.age,
          description: celebrity.description,
          popularityScore: celebrity.popularityScore,
          sentimentScore: celebrity.sentimentScore,
          credibilityScore: celebrity.credibilityScore,
          engagementScore: celebrity.engagementScore,
          recentActivity: celebrity.recentActivity || [],
        })
      }
    } catch (mongoError) {
      // If not a valid MongoDB ID, try to decode as a name
      console.error("Not a valid MongoDB ID, trying as name:", mongoError)
    }

    // If not found by ID, try to fetch by name
    try {
      // Assume ID might be a base64 encoded name
      const name = Buffer.from(id, "base64").toString()
      const celebrity = await fetchCelebrityProfile(name)
      return NextResponse.json(celebrity)
    } catch (nameError) {
      console.error("Error fetching by name:", nameError)
      return NextResponse.json({ error: "Celebrity not found" }, { status: 404 })
    }
  } catch (error) {
    console.error("Error fetching celebrity:", error)
    return NextResponse.json({ error: "Failed to fetch celebrity" }, { status: 500 })
  }
}

