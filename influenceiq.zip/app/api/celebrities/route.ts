import { NextResponse } from "next/server"
import { fetchTopCelebrities, searchCelebrities } from "@/lib/api"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const query = searchParams.get("q")
    const limit = Number.parseInt(searchParams.get("limit") || "10")

    if (query) {
      const results = await searchCelebrities(query)
      return NextResponse.json(results)
    }

    const celebrities = await fetchTopCelebrities(limit)
    return NextResponse.json(celebrities)
  } catch (error) {
    console.error("Error fetching celebrities:", error)
    return NextResponse.json({ error: "Failed to fetch celebrities" }, { status: 500 })
  }
}

