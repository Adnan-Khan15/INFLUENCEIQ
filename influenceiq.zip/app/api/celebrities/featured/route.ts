import { NextResponse } from "next/server"
import { fetchTopCelebrities } from "@/lib/api"

export async function GET() {
  try {
    // Get top 3 celebrities for the featured carousel
    const topCelebrities = await fetchTopCelebrities(3)

    return NextResponse.json(topCelebrities)
  } catch (error) {
    console.error("Error fetching featured celebrities:", error)
    return NextResponse.json({ error: "Failed to fetch featured celebrities" }, { status: 500 })
  }
}

