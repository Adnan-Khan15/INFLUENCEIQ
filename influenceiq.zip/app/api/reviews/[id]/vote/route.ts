import { NextResponse } from "next/server"
import { voteOnReview } from "@/lib/api"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"

export async function POST(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !session.user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 })
    }

    const reviewId = params.id
    const { isUpvote } = await request.json()

    if (typeof isUpvote !== "boolean") {
      return NextResponse.json({ error: "isUpvote must be a boolean" }, { status: 400 })
    }

    await voteOnReview(reviewId, isUpvote)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error voting on review:", error)
    return NextResponse.json({ error: "Failed to vote on review" }, { status: 500 })
  }
}

