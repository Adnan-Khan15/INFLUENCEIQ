import { NextResponse } from "next/server"
import { getCelebrityReviews, addCelebrityReview } from "@/lib/api"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const celebrityId = searchParams.get("celebrityId")

    if (!celebrityId) {
      return NextResponse.json({ error: "Celebrity ID is required" }, { status: 400 })
    }

    const reviews = await getCelebrityReviews(celebrityId)
    return NextResponse.json(reviews)
  } catch (error) {
    console.error("Error fetching reviews:", error)
    return NextResponse.json({ error: "Failed to fetch reviews" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !session.user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 })
    }

    const body = await request.json()

    // Validate required fields
    if (!body.celebrityId || !body.content || !body.rating) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Validate rating
    if (body.rating < 1 || body.rating > 10 || !Number.isInteger(body.rating)) {
      return NextResponse.json({ error: "Rating must be an integer between 1 and 10" }, { status: 400 })
    }

    const review = await addCelebrityReview({
      celebrityId: body.celebrityId,
      userId: session.user.id,
      content: body.content,
      rating: body.rating,
    })

    return NextResponse.json(review, { status: 201 })
  } catch (error) {
    console.error("Error creating review:", error)
    return NextResponse.json({ error: "Failed to create review" }, { status: 500 })
  }
}

