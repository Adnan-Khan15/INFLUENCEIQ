import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import clientPromise from "@/lib/mongodb"
import { ObjectId } from "mongodb"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)

    // Only allow users to view their own reviews or admins to view any reviews
    if (!session || (session.user.id !== params.id && session.user.role !== "admin")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const client = await clientPromise
    const db = client.db()

    // Get user's reviews
    const reviews = await db.collection("reviews").find({ userId: params.id }).sort({ date: -1 }).toArray()

    // Get celebrity info for each review
    const reviewsWithCelebrityInfo = await Promise.all(
      reviews.map(async (review) => {
        let celebrityName = "Unknown Celebrity"

        try {
          const celebrity = await db.collection("celebrities").findOne({ _id: new ObjectId(review.celebrityId) })
          if (celebrity) {
            celebrityName = celebrity.name
          }
        } catch (celebrityError) {
          console.error("Error fetching celebrity for review:", celebrityError)
        }

        return {
          id: review._id.toString(),
          celebrityId: review.celebrityId,
          celebrityName,
          userId: review.userId,
          userName: session.user.name,
          userImage: session.user.image,
          content: review.content,
          rating: review.rating,
          date: review.date,
          upvotes: review.upvotes,
          downvotes: review.downvotes,
        }
      }),
    )

    return NextResponse.json(reviewsWithCelebrityInfo)
  } catch (error) {
    console.error("Error getting user reviews:", error)
    return NextResponse.json({ error: "Failed to get user reviews" }, { status: 500 })
  }
}

