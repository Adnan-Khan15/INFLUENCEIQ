import { NextResponse } from "next/server"
import { fetchCelebrityInfo, calculatePopularityScore, analyzeSentiment } from "@/lib/api"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const query = searchParams.get("q")

    if (!query) {
      return NextResponse.json({ error: "Search query is required" }, { status: 400 })
    }

    // In a real app, this would search for the celebrity using external APIs
    const celebrityInfo = await fetchCelebrityInfo(query)

    if (!celebrityInfo.name) {
      return NextResponse.json({ error: "No results found" }, { status: 404 })
    }

    // Calculate scores based on data from APIs
    const popularityScore = await calculatePopularityScore(query)
    const sentimentScore = await analyzeSentiment(query)

    const result = {
      id: Date.now().toString(),
      ...celebrityInfo,
      popularityScore,
      sentimentScore,
      credibilityScore: 5 + Math.random() * 5,
      engagementScore: 5 + Math.random() * 5,
    }

    return NextResponse.json(result)
  } catch (error) {
    console.error("Error searching for celebrity:", error)
    return NextResponse.json({ error: "Failed to search for celebrity" }, { status: 500 })
  }
}

