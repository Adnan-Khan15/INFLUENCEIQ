import { Suspense } from "react"
import Link from "next/link"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Skeleton } from "@/components/ui/skeleton"
import { CelebrityCard } from "@/components/celebrity-card"
import { TrendingCelebrities } from "@/components/trending-celebrities"
import { FeaturedCarousel } from "@/components/featured-carousel"
import { AuthButton } from "@/components/auth-button"
import { fetchTopCelebrities } from "@/lib/api"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center">
          <Link href="/" className="flex items-center gap-2 font-bold text-xl">
            <span className="text-primary">Influence</span>
            <span>IQ</span>
          </Link>
          <div className="flex flex-1 items-center justify-end space-x-4">
            <div className="relative w-full max-w-sm">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <form action="/search">
                <Input type="search" name="q" placeholder="Search celebrities..." className="w-full pl-8" />
              </form>
            </div>
            <AuthButton />
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="container py-10">
          <h1 className="text-3xl font-bold mb-6">Discover Influential Figures</h1>
          <p className="text-muted-foreground mb-8 max-w-3xl">
            InfluenceIQ ranks public figures based on credibility, engagement, and sentiment analysis. Explore our
            leaderboard to find the most influential people right now.
          </p>

          <Tabs defaultValue="leaderboard" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
              <TabsTrigger value="trending">Trending</TabsTrigger>
              <TabsTrigger value="featured">Featured</TabsTrigger>
            </TabsList>
            <TabsContent value="leaderboard">
              <h2 className="text-2xl font-bold mb-4">Top 10 Influencers This Week</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Suspense fallback={<LeaderboardSkeleton />}>
                  <TopCelebrities />
                </Suspense>
              </div>
            </TabsContent>
            <TabsContent value="trending">
              <h2 className="text-2xl font-bold mb-4">Trending Now</h2>
              <Suspense fallback={<LeaderboardSkeleton />}>
                <TrendingCelebrities />
              </Suspense>
            </TabsContent>
            <TabsContent value="featured">
              <h2 className="text-2xl font-bold mb-4">Featured Profiles</h2>
              <Suspense fallback={<div className="h-80 w-full bg-muted/20 animate-pulse rounded-lg" />}>
                <FeaturedCarousel />
              </Suspense>
            </TabsContent>
          </Tabs>
        </section>
      </main>
      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} InfluenceIQ. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <Link href="https://github.com/Adnan-Khan15" className="text-sm text-muted-foreground underline">
              About
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

function LeaderboardSkeleton() {
  return (
    <>
      {Array(6)
        .fill(0)
        .map((_, i) => (
          <Card key={i} className="overflow-hidden">
            <CardContent className="p-0">
              <div className="flex flex-col">
                <Skeleton className="h-48 w-full" />
                <div className="p-4">
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-full mb-4" />
                  <div className="flex justify-between">
                    <Skeleton className="h-8 w-24" />
                    <Skeleton className="h-8 w-24" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
    </>
  )
}

async function TopCelebrities() {
  const celebrities = await fetchTopCelebrities(6)

  return (
    <>
      {celebrities.map((celebrity) => (
        <CelebrityCard key={celebrity.id} celebrity={celebrity} />
      ))}
    </>
  )
}

