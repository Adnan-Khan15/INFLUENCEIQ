"use client"

import {
  Chart,
  ChartContainer,
  ChartLegend,
  ChartLegendContent,
  ChartTooltip,
  ChartTooltipContent,
  Bar,
  BarChart,
  CategoryScale,
  LinearScale,
} from "@/components/ui/chart"

interface SentimentBreakdownProps {
  credibility: number
  engagement: number
  sentiment: number
}

export function SentimentBreakdown({ credibility, engagement, sentiment }: SentimentBreakdownProps) {
  const data = [
    { name: "Credibility", value: credibility },
    { name: "Engagement", value: engagement },
    { name: "Sentiment", value: sentiment },
  ]

  return (
    <ChartContainer className="h-64">
      <Chart>
        <CategoryScale />
        <LinearScale min={0} max={10} />
        <BarChart data={data} xField="name" yField="value" colors={["hsl(var(--primary))"]}>
          <Bar />
          <ChartTooltip>
            <ChartTooltipContent />
          </ChartTooltip>
        </BarChart>
      </Chart>
      <ChartLegend>
        <ChartLegendContent />
      </ChartLegend>
    </ChartContainer>
  )
}

