import { CelebrityCard } from "@/components/celebrity-card"
import { fetchTrendingCelebrities } from "@/lib/api"

export async function TrendingCelebrities() {
  const celebrities = await fetchTrendingCelebrities()

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {celebrities.map((celebrity) => (
        <CelebrityCard key={celebrity.id} celebrity={celebrity} />
      ))}
    </div>
  )
}

