"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { ChevronLeft, ChevronRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import type { Celebrity } from "@/lib/types"

export function FeaturedCarousel() {
  const router = useRouter()
  const [currentIndex, setCurrentIndex] = useState(0)
  const [featuredCelebrities, setFeaturedCelebrities] = useState<Celebrity[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchFeatured() {
      try {
        const response = await fetch("/api/celebrities/featured")
        if (!response.ok) throw new Error("Failed to fetch featured celebrities")
        const data = await response.json()
        setFeaturedCelebrities(data)
      } catch (error) {
        console.error("Error fetching featured celebrities:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchFeatured()
  }, [])

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex === featuredCelebrities.length - 1 ? 0 : prevIndex + 1))
  }

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? featuredCelebrities.length - 1 : prevIndex - 1))
  }

  if (loading) {
    return <div className="h-80 w-full bg-muted/20 animate-pulse rounded-lg" />
  }

  if (featuredCelebrities.length === 0) {
    return (
      <div className="h-80 w-full flex items-center justify-center border rounded-lg">
        No featured celebrities found
      </div>
    )
  }

  const celebrity = featuredCelebrities[currentIndex]

  return (
    <div className="relative w-full h-80 rounded-lg overflow-hidden">
      <div className="absolute inset-0 cursor-pointer" onClick={() => router.push(`/profile/${celebrity.id}`)}>
        <Image src={celebrity.image || "/placeholder.svg"} alt={celebrity.name} fill className="object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
      </div>

      <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
        <h3 className="text-2xl font-bold mb-2">{celebrity.name}</h3>
        <p className="mb-4 max-w-2xl">{celebrity.description}</p>
        <div className="flex gap-3">
          <Badge className="bg-primary/80 hover:bg-primary">Popularity: {celebrity.popularityScore.toFixed(1)}</Badge>
          <Badge className="bg-primary/80 hover:bg-primary">Sentiment: {celebrity.sentimentScore.toFixed(1)}</Badge>
        </div>
      </div>

      <Button
        variant="ghost"
        size="icon"
        className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/30 text-white hover:bg-black/50"
        onClick={(e) => {
          e.stopPropagation()
          prevSlide()
        }}
      >
        <ChevronLeft className="h-6 w-6" />
      </Button>

      <Button
        variant="ghost"
        size="icon"
        className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/30 text-white hover:bg-black/50"
        onClick={(e) => {
          e.stopPropagation()
          nextSlide()
        }}
      >
        <ChevronRight className="h-6 w-6" />
      </Button>
    </div>
  )
}

