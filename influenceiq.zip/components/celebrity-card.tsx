"use client"

import { useRouter } from "next/navigation"
import Image from "next/image"
import { BarChart2, Heart } from "lucide-react"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { Celebrity } from "@/lib/types"

export function CelebrityCard({ celebrity }: { celebrity: Celebrity }) {
  const router = useRouter()

  const handleClick = () => {
    router.push(`/profile/${celebrity.id}`)
  }

  return (
    <Card className="overflow-hidden cursor-pointer transition-all hover:shadow-lg" onClick={handleClick}>
      <CardContent className="p-0">
        <div className="flex flex-col">
          <div className="relative h-48 w-full">
            <Image src={celebrity.image || "/placeholder.svg"} alt={celebrity.name} fill className="object-cover" />
          </div>
          <div className="p-4">
            <h3 className="font-bold text-lg">{celebrity.name}</h3>
            <p className="text-muted-foreground text-sm mb-4 line-clamp-2">{celebrity.description}</p>
            <div className="flex justify-between">
              <Badge variant="outline" className="flex items-center gap-1">
                <BarChart2 className="h-3 w-3" />
                <span>Popularity: {celebrity.popularityScore.toFixed(1)}</span>
              </Badge>
              <Badge variant="outline" className="flex items-center gap-1">
                <Heart className="h-3 w-3" />
                <span>Sentiment: {celebrity.sentimentScore.toFixed(1)}</span>
              </Badge>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

