"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ThumbsDown, ThumbsUp } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useToast } from "@/hooks/use-toast"
import type { Review } from "@/lib/types"

export function UserReviewsList({ userId }: { userId: string }) {
  const { toast } = useToast()
  const [reviews, setReviews] = useState<Review[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchUserReviews() {
      try {
        const response = await fetch(`/api/users/${userId}/reviews`)
        if (!response.ok) throw new Error("Failed to fetch reviews")
        const data = await response.json()
        setReviews(data)
      } catch (error) {
        console.error("Error fetching user reviews:", error)
        toast({
          title: "Error",
          description: "Failed to load your reviews",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchUserReviews()
  }, [userId, toast])

  if (loading) {
    return <div className="h-64 w-full bg-muted/20 animate-pulse rounded-lg" />
  }

  if (reviews.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground mb-4">You haven't written any reviews yet.</p>
        <Link href="/">
          <Button>Explore Celebrities</Button>
        </Link>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {reviews.map((review) => (
        <div key={review.id} className="border rounded-lg p-4">
          <div className="flex items-start gap-3">
            <Avatar>
              <AvatarImage src={review.userImage || undefined} alt={review.userName || "User"} />
              <AvatarFallback>{(review.userName || "User").charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex justify-between">
                <div>
                  <Link href={`/profile/${review.celebrityId}`}>
                    <p className="font-medium hover:underline">{review.celebrityName || "Celebrity"}</p>
                  </Link>
                  <p className="text-sm text-muted-foreground">{new Date(review.date).toLocaleDateString()}</p>
                </div>
                <div className="text-sm font-medium">Rating: {review.rating}/10</div>
              </div>
              <p className="mt-2">{review.content}</p>
              <div className="flex gap-4 mt-4">
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <ThumbsUp className="h-4 w-4" />
                  <span>{review.upvotes}</span>
                </div>
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <ThumbsDown className="h-4 w-4" />
                  <span>{review.downvotes}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

