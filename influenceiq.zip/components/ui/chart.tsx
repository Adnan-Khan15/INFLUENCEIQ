"use client"

import type * as React from "react"

const ChartContainer = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => {
  return <div className={className} {...props} />
}

const Chart = ({ children, ...props }: React.HTMLAttributes<HTMLDivElement>) => {
  return (
    <svg viewBox="0 0 100 100" preserveAspectRatio="none" width="100%" height="100%" {...props}>
      {children}
    </svg>
  )
}

const Line = ({ ...props }: React.SVGProps<SVGPathElement>) => {
  return <path stroke="currentColor" strokeWidth="1" fill="none" {...props} />
}

const LineChart = ({
  data,
  xField,
  yField,
  curveType,
  colors,
  children,
}: {
  data: any[]
  xField: string
  yField: string
  curveType: string
  colors: string[]
  children: React.ReactNode
}) => {
  return <g>{children}</g>
}

const LinearScale = ({ min, max }: { min: number; max: number }) => {
  return null
}

const TimeScale = () => {
  return null
}

const Bar = ({ ...props }: React.SVGProps<SVGRectElement>) => {
  return <rect fill="currentColor" {...props} />
}

const BarChart = ({
  data,
  xField,
  yField,
  colors,
  children,
}: {
  data: any[]
  xField: string
  yField: string
  colors: string[]
  children: React.ReactNode
}) => {
  return <g>{children}</g>
}

const CategoryScale = () => {
  return null
}

const ChartTooltip = ({ children }: { children: React.ReactNode }) => {
  return <g>{children}</g>
}

const ChartTooltipContent = () => {
  return null
}

const ChartLegend = ({ children }: { children: React.ReactNode }) => {
  return <g>{children}</g>
}

const ChartLegendContent = () => {
  return null
}

export {
  Chart,
  Line,
  LineChart,
  LinearScale,
  TimeScale,
  Bar,
  BarChart,
  CategoryScale,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
}

