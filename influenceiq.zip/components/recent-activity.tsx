interface ActivityItem {
  date: string
  platform: string
  content: string
}

export function RecentActivity({ activity }: { activity: ActivityItem[] }) {
  return (
    <div className="space-y-4">
      {activity.length > 0 ? (
        activity.map((item, index) => (
          <div key={index} className="flex items-start gap-4 pb-4 border-b last:border-0">
            <div className="min-w-24 text-sm text-muted-foreground">{new Date(item.date).toLocaleDateString()}</div>
            <div>
              <div className="font-medium">{item.platform}</div>
              <p className="text-sm text-muted-foreground">{item.content}</p>
            </div>
          </div>
        ))
      ) : (
        <p className="text-muted-foreground text-center py-8">No recent activity found</p>
      )}
    </div>
  )
}

