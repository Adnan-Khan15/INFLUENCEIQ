"use client"

import { useEffect, useState } from "react"
import {
  Chart,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  Line,
  LineChart,
  LinearScale,
  TimeScale,
} from "@/components/ui/chart"

interface PopularityData {
  date: string
  value: number
}

export function PopularityChart({ celebrityId }: { celebrityId: string }) {
  const [data, setData] = useState<PopularityData[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchData() {
      try {
        const response = await fetch(`/api/celebrities/${celebrityId}/trend`)
        if (!response.ok) throw new Error("Failed to fetch trend data")
        const trendData = await response.json()
        setData(trendData)
      } catch (error) {
        console.error("Failed to fetch popularity data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [celebrityId])

  if (loading) {
    return <div className="h-64 w-full bg-muted/20 animate-pulse rounded-lg" />
  }

  return (
    <ChartContainer className="h-64">
      <Chart>
        <TimeScale />
        <LinearScale min={0} max={10} />
        <LineChart data={data} xField="date" yField="value" curveType="monotone" colors={["hsl(var(--primary))"]}>
          <Line />
          <ChartTooltip>
            <ChartTooltipContent />
          </ChartTooltip>
        </LineChart>
      </Chart>
    </ChartContainer>
  )
}

