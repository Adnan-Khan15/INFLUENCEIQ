"use client"

import { useState, useEffect } from "react"
import { useSession } from "next-auth/react"
import { ThumbsDown, ThumbsUp } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useToast } from "@/hooks/use-toast"
import type { Review } from "@/lib/types"

export function UserReviews({ celebrityId }: { celebrityId: string }) {
  const { data: session } = useSession()
  const { toast } = useToast()
  const [reviews, setReviews] = useState<Review[]>([])
  const [loading, setLoading] = useState(true)
  const [newReview, setNewReview] = useState("")
  const [rating, setRating] = useState(5)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    async function fetchReviews() {
      try {
        const response = await fetch(`/api/reviews?celebrityId=${celebrityId}`)
        if (!response.ok) throw new Error("Failed to fetch reviews")
        const data = await response.json()
        setReviews(data)
      } catch (error) {
        console.error("Error fetching reviews:", error)
        toast({
          title: "Error",
          description: "Failed to load reviews",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchReviews()
  }, [celebrityId, toast])

  const handleVote = async (reviewId: string, isUpvote: boolean) => {
    if (!session) {
      toast({
        title: "Authentication required",
        description: "Please log in to vote on reviews",
        variant: "destructive",
      })
      return
    }

    try {
      const response = await fetch(`/api/reviews/${reviewId}/vote`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ isUpvote }),
      })

      if (!response.ok) throw new Error("Failed to vote")

      // Update local state
      setReviews(
        reviews.map((review) => {
          if (review.id === reviewId) {
            if (isUpvote) {
              return { ...review, upvotes: review.upvotes + 1 }
            } else {
              return { ...review, downvotes: review.downvotes + 1 }
            }
          }
          return review
        }),
      )

      toast({
        title: "Success",
        description: `Your ${isUpvote ? "upvote" : "downvote"} has been recorded`,
      })
    } catch (error) {
      console.error("Error voting:", error)
      toast({
        title: "Error",
        description: "Failed to record your vote",
        variant: "destructive",
      })
    }
  }

  const handleSubmitReview = async () => {
    if (!session) {
      toast({
        title: "Authentication required",
        description: "Please log in to submit a review",
        variant: "destructive",
      })
      return
    }

    if (!newReview.trim()) {
      toast({
        title: "Error",
        description: "Review content cannot be empty",
        variant: "destructive",
      })
      return
    }

    setSubmitting(true)

    try {
      const response = await fetch("/api/reviews", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          celebrityId,
          content: newReview,
          rating,
        }),
      })

      if (!response.ok) throw new Error("Failed to submit review")

      const newReviewData = await response.json()

      // Add new review to the list
      setReviews([newReviewData, ...reviews])
      setNewReview("")
      setRating(5)

      toast({
        title: "Success",
        description: "Your review has been submitted",
      })
    } catch (error) {
      console.error("Error submitting review:", error)
      toast({
        title: "Error",
        description: "Failed to submit your review",
        variant: "destructive",
      })
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) {
    return <div className="h-64 w-full bg-muted/20 animate-pulse rounded-lg" />
  }

  return (
    <div className="space-y-6">
      {session && (
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Write a Review</h3>
          <div className="space-y-2">
            <label htmlFor="rating" className="block text-sm font-medium">
              Rating (1-10): {rating}
            </label>
            <input
              type="range"
              id="rating"
              min="1"
              max="10"
              value={rating}
              onChange={(e) => setRating(Number.parseInt(e.target.value))}
              className="w-full"
            />
          </div>
          <Textarea
            placeholder="Share your thoughts about this celebrity..."
            value={newReview}
            onChange={(e) => setNewReview(e.target.value)}
            className="min-h-24"
          />
          <Button onClick={handleSubmitReview} disabled={submitting}>
            {submitting ? "Submitting..." : "Submit Review"}
          </Button>
        </div>
      )}

      <div className="space-y-6">
        <h3 className="text-lg font-medium">Reviews ({reviews.length})</h3>

        {reviews.length === 0 ? (
          <p className="text-center py-8 text-muted-foreground">No reviews yet. Be the first to review!</p>
        ) : (
          reviews.map((review) => (
            <div key={review.id} className="border rounded-lg p-4">
              <div className="flex items-start gap-3">
                <Avatar>
                  <AvatarImage src={review.userImage || undefined} alt={review.userName || "User"} />
                  <AvatarFallback>{(review.userName || "User").charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex justify-between">
                    <div>
                      <p className="font-medium">{review.userName || "Anonymous"}</p>
                      <p className="text-sm text-muted-foreground">{new Date(review.date).toLocaleDateString()}</p>
                    </div>
                    <div className="text-sm font-medium">Rating: {review.rating}/10</div>
                  </div>
                  <p className="mt-2">{review.content}</p>
                  <div className="flex gap-4 mt-4">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="flex items-center gap-1"
                      onClick={() => handleVote(review.id!, true)}
                    >
                      <ThumbsUp className="h-4 w-4" />
                      <span>{review.upvotes}</span>
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="flex items-center gap-1"
                      onClick={() => handleVote(review.id!, false)}
                    >
                      <ThumbsDown className="h-4 w-4" />
                      <span>{review.downvotes}</span>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}

