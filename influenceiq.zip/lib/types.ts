import type { ObjectId } from "mongodb"

export interface Celebrity {
  id: string
  name: string
  image: string
  age?: number
  description: string
  popularityScore: number
  sentimentScore: number
  credibilityScore: number
  engagementScore: number
  recentActivity: {
    date: string
    platform: string
    content: string
  }[]
}

export interface User {
  _id?: ObjectId
  id?: string
  name: string
  email: string
  password?: string
  image?: string | null
  createdAt?: Date
}

export interface Review {
  _id?: ObjectId
  id?: string
  celebrityId: string
  userId: string
  userName?: string
  userImage?: string
  content: string
  rating: number
  date: string
  upvotes: number
  downvotes: number
}

export interface NewsArticle {
  title: string
  url: string
  source: string
  publishedAt: string
  content: string
}

export interface SocialMediaPost {
  platform: string
  content: string
  date: string
  sentiment?: number
}

