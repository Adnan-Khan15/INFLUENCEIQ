import type { Celebrity, NewsArticle, SocialMediaPost, Review } from "@/lib/types"
import clientPromise from "@/lib/mongodb"
import { ObjectId } from "mongodb"
import axios from "axios"
import Sentiment from "sentiment"

// Initialize sentiment analyzer
const sentiment = new Sentiment()

// Fetch celebrity info from Wikipedia
export async function fetchCelebrityInfo(name: string): Promise<Partial<Celebrity>> {
  try {
    // Use Wikipedia API to get basic info
    const response = await axios.get(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(name)}`)

    if (response.status !== 200) {
      throw new Error("Failed to fetch from Wikipedia")
    }

    const data = response.data

    // Get age if available
    let age: number | undefined = undefined
    try {
      const wikiTextResponse = await axios.get(
        `https://en.wikipedia.org/w/api.php?action=query&prop=extracts&exintro&explaintext&titles=${encodeURIComponent(name)}&format=json&origin=*`,
      )

      const pages = wikiTextResponse.data.query.pages
      const pageId = Object.keys(pages)[0]
      const extract = pages[pageId].extract

      // Try to find birth year in the text
      const birthYearMatch = extract.match(/$$born\s+(\d{4})$$/) || extract.match(/born\s+\w+\s+\d+,\s+(\d{4})/)

      if (birthYearMatch && birthYearMatch[1]) {
        const birthYear = Number.parseInt(birthYearMatch[1])
        const currentYear = new Date().getFullYear()
        age = currentYear - birthYear
      }
    } catch (error) {
      console.error("Error fetching age:", error)
    }

    return {
      name: data.title,
      description: data.extract,
      image: data.thumbnail?.source || `/placeholder.svg?height=400&width=400&text=${encodeURIComponent(name)}`,
      age,
    }
  } catch (error) {
    console.error("Error fetching celebrity info:", error)
    // Return basic info if Wikipedia fails
    return {
      name,
      description: `Information about ${name}`,
      image: `/placeholder.svg?height=400&width=400&text=${encodeURIComponent(name)}`,
    }
  }
}

// Fetch news articles about a celebrity using NewsAPI
export async function fetchNewsArticles(name: string): Promise<NewsArticle[]> {
  try {
    if (!process.env.NEWS_API_KEY) {
      throw new Error("NEWS_API_KEY is not defined")
    }

    const response = await axios.get(
      `https://newsapi.org/v2/everything?q=${encodeURIComponent(name)}&apiKey=${process.env.NEWS_API_KEY}&pageSize=10&language=en&sortBy=publishedAt`,
    )

    if (response.status !== 200) {
      throw new Error("Failed to fetch from News API")
    }

    return response.data.articles.map((article: any) => ({
      title: article.title,
      url: article.url,
      source: article.source.name,
      publishedAt: article.publishedAt,
      content: article.content || article.description || "",
    }))
  } catch (error) {
    console.error("Error fetching news articles:", error)
    return []
  }
}

// Fetch Twitter data using Twitter API v2
export async function fetchTwitterData(name: string): Promise<SocialMediaPost[]> {
  try {
    if (!process.env.TWITTER_BEARER_TOKEN) {
      throw new Error("TWITTER_BEARER_TOKEN is not defined")
    }

    const response = await axios.get(
      `https://api.twitter.com/2/tweets/search/recent?query=${encodeURIComponent(name)}&max_results=10&tweet.fields=created_at`,
      {
        headers: {
          Authorization: `Bearer ${process.env.TWITTER_BEARER_TOKEN}`,
        },
      },
    )

    if (response.status !== 200) {
      throw new Error("Failed to fetch from Twitter API")
    }

    return response.data.data.map((tweet: any) => ({
      platform: "Twitter",
      content: tweet.text,
      date: tweet.created_at,
      sentiment: analyzeSentiment(tweet.text),
    }))
  } catch (error) {
    console.error("Error fetching Twitter data:", error)
    return []
  }
}

// Analyze sentiment of text
export function analyzeSentiment(text: string): number {
  try {
    const result = sentiment.analyze(text)

    // Convert from sentiment.js scale to 1-10 scale
    // sentiment.js typically ranges from around -10 to +10
    const normalizedScore = ((result.comparative + 5) / 10) * 9 + 1

    // Ensure score is within 1-10 range
    return Math.max(1, Math.min(10, normalizedScore))
  } catch (error) {
    console.error("Error analyzing sentiment:", error)
    return 5 // Neutral sentiment
  }
}

// Calculate overall sentiment score from news articles
export async function calculateSentimentScore(name: string): Promise<number> {
  try {
    // Get news articles
    const articles = await fetchNewsArticles(name)

    if (articles.length === 0) {
      return 5 // Default neutral score if no articles
    }

    // Calculate sentiment for each article
    const sentiments = articles.map((article) => analyzeSentiment(article.content))

    // Calculate average sentiment
    const avgSentiment = sentiments.reduce((sum, val) => sum + val, 0) / sentiments.length

    return Math.round(avgSentiment * 10) / 10
  } catch (error) {
    console.error("Error calculating sentiment score:", error)
    return 5 // Default neutral score
  }
}

// Calculate popularity score based on Google Trends data
export async function calculatePopularityScore(name: string): Promise<number> {
  try {
    // Use Google Trends API (via unofficial npm package)
    const googleTrends = require("google-trends-api")

    // Get interest over time for the past 30 days
    const result = await googleTrends.interestOverTime({
      keyword: name,
      startTime: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
    })

    const data = JSON.parse(result)

    // Calculate average interest
    const timelineData = data.default.timelineData
    const interestValues = timelineData.map((point: any) => point.value[0])
    const avgInterest = interestValues.reduce((sum: number, val: number) => sum + val, 0) / interestValues.length

    // Google Trends data is 0-100, convert to 1-10 scale
    const popularityScore = (avgInterest / 100) * 9 + 1

    return Math.round(popularityScore * 10) / 10
  } catch (error) {
    console.error("Error calculating popularity score:", error)

    // Fallback: Use news article count as a proxy for popularity
    try {
      const articles = await fetchNewsArticles(name)
      // More articles = more popular, up to 20 articles
      const articleScore = Math.min(articles.length / 2, 10)
      return Math.max(1, Math.round(articleScore * 10) / 10)
    } catch (fallbackError) {
      console.error("Error in popularity fallback:", fallbackError)
      return 5 // Default score
    }
  }
}

// Calculate credibility score
export async function calculateCredibilityScore(name: string): Promise<number> {
  try {
    // Check if the person has a Wikipedia page as a credibility indicator
    const wikiInfo = await fetchCelebrityInfo(name)
    const hasDetailedWikipedia = !!wikiInfo.description && wikiInfo.description.length > 200

    // Get news articles from reputable sources
    const articles = await fetchNewsArticles(name)
    const reputableSources = ["BBC", "Reuters", "Associated Press", "The New York Times", "The Washington Post"]
    const reputableArticles = articles.filter((article) =>
      reputableSources.some((source) => article.source.includes(source)),
    )

    // Calculate base score
    let baseScore = 5.0

    // Adjust for Wikipedia presence
    if (hasDetailedWikipedia) baseScore += 2

    // Adjust for reputable sources coverage
    baseScore += Math.min(reputableArticles.length, 3)

    // Ensure score is within 1-10 range
    const credibilityScore = Math.max(1, Math.min(10, baseScore))

    return Math.round(credibilityScore * 10) / 10
  } catch (error) {
    console.error("Error calculating credibility score:", error)
    return 5 // Default score
  }
}

// Calculate engagement score
export async function calculateEngagementScore(name: string): Promise<number> {
  try {
    // Use Twitter data as engagement indicator
    const twitterPosts = await fetchTwitterData(name)

    // More tweets = more engagement, up to 10 tweets
    const tweetScore = Math.min(twitterPosts.length, 10)

    // Ensure score is within 1-10 range
    return Math.max(1, tweetScore)
  } catch (error) {
    console.error("Error calculating engagement score:", error)
    return 5 // Default score
  }
}

// Get recent activity for a celebrity
export async function getRecentActivity(name: string): Promise<{ date: string; platform: string; content: string }[]> {
  try {
    // Get Twitter posts
    const twitterPosts = await fetchTwitterData(name)
    const twitterActivity = twitterPosts.map((post) => ({
      date: new Date(post.date).toISOString().split("T")[0],
      platform: "Twitter",
      content: post.content.substring(0, 100) + (post.content.length > 100 ? "..." : ""),
    }))

    // Get news articles
    const articles = await fetchNewsArticles(name)
    const newsActivity = articles.map((article) => ({
      date: new Date(article.publishedAt).toISOString().split("T")[0],
      platform: article.source,
      content: article.title,
    }))

    // Combine and sort by date
    const allActivity = [...twitterActivity, ...newsActivity]
    allActivity.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())

    return allActivity.slice(0, 5) // Return top 5 most recent activities
  } catch (error) {
    console.error("Error getting recent activity:", error)
    return []
  }
}

// Get popularity trend data for a celebrity
export async function getPopularityTrend(name: string): Promise<{ date: string; value: number }[]> {
  try {
    // Use Google Trends API for historical data
    const googleTrends = require("google-trends-api")

    // Get interest over time for the past 7 days
    const result = await googleTrends.interestOverTime({
      keyword: name,
      startTime: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
    })

    const data = JSON.parse(result)

    // Format the data
    return data.default.timelineData.map((point: any) => {
      const date = new Date(Number.parseInt(point.time) * 1000)
      // Convert from 0-100 to 1-10 scale
      const value = (point.value[0] / 100) * 9 + 1

      return {
        date: date.toISOString().split("T")[0],
        value: Math.round(value * 10) / 10,
      }
    })
  } catch (error) {
    console.error("Error getting popularity trend:", error)

    // Fallback: Generate a trend based on current popularity
    const today = new Date()
    const basePopularity = Math.random() * 5 + 3 // Random base between 3-8

    return Array.from({ length: 7 }).map((_, i) => {
      const date = new Date(today)
      date.setDate(date.getDate() - (6 - i))

      // Add some variation to create a trend
      const variation = (Math.random() - 0.5) * 2
      const value = Math.max(1, Math.min(10, basePopularity + variation))

      return {
        date: date.toISOString().split("T")[0],
        value: Math.round(value * 10) / 10,
      }
    })
  }
}

// Fetch or create celebrity profile with all metrics
export async function fetchCelebrityProfile(name: string): Promise<Celebrity> {
  try {
    const client = await clientPromise
    const db = client.db()

    // Check if we already have this celebrity in the database
    const existingCelebrity = await db
      .collection("celebrities")
      .findOne({ name: { $regex: new RegExp(`^${name}$`, "i") } })

    if (existingCelebrity) {
      // Update the profile if it's older than 24 hours
      const lastUpdated = existingCelebrity.updatedAt || existingCelebrity.createdAt
      const isStale = Date.now() - new Date(lastUpdated).getTime() > 24 * 60 * 60 * 1000

      if (!isStale) {
        return {
          id: existingCelebrity._id.toString(),
          name: existingCelebrity.name,
          image: existingCelebrity.image,
          age: existingCelebrity.age,
          description: existingCelebrity.description,
          popularityScore: existingCelebrity.popularityScore,
          sentimentScore: existingCelebrity.sentimentScore,
          credibilityScore: existingCelebrity.credibilityScore,
          engagementScore: existingCelebrity.engagementScore,
          recentActivity: existingCelebrity.recentActivity || [],
        }
      }
    }

    // Get basic info
    const basicInfo = await fetchCelebrityInfo(name)

    // Calculate scores
    const popularityScore = await calculatePopularityScore(name)
    const sentimentScore = await calculateSentimentScore(name)
    const credibilityScore = await calculateCredibilityScore(name)
    const engagementScore = await calculateEngagementScore(name)

    // Get recent activity
    const recentActivity = await getRecentActivity(name)

    // Create or update celebrity profile
    const celebrity = {
      name: basicInfo.name || name,
      image: basicInfo.image || `/placeholder.svg?height=400&width=400&text=${encodeURIComponent(name)}`,
      age: basicInfo.age,
      description: basicInfo.description || `Public figure known as ${name}`,
      popularityScore,
      sentimentScore,
      credibilityScore,
      engagementScore,
      recentActivity,
      updatedAt: new Date(),
    }

    let id: string

    if (existingCelebrity) {
      // Update existing record
      await db.collection("celebrities").updateOne({ _id: existingCelebrity._id }, { $set: celebrity })
      id = existingCelebrity._id.toString()
    } else {
      // Create new record
      celebrity.createdAt = new Date()
      const result = await db.collection("celebrities").insertOne(celebrity)
      id = result.insertedId.toString()
    }

    return {
      id,
      ...celebrity,
    }
  } catch (error) {
    console.error("Error fetching celebrity profile:", error)
    throw error
  }
}

// Fetch top celebrities for the leaderboard
export async function fetchTopCelebrities(count = 10): Promise<Celebrity[]> {
  try {
    const client = await clientPromise
    const db = client.db()

    // Get celebrities from database, sorted by popularity
    const celebrities = await db.collection("celebrities").find({}).sort({ popularityScore: -1 }).limit(count).toArray()

    // If we don't have enough celebrities, fetch some popular ones
    if (celebrities.length < count) {
      const popularNames = [
        "Elon Musk",
        "Taylor Swift",
        "LeBron James",
        "Beyoncé",
        "Cristiano Ronaldo",
        "Oprah Winfrey",
        "Dwayne Johnson",
        "Zendaya",
        "Tom Holland",
        "Billie Eilish",
      ]

      // Filter out names we already have
      const existingNames = celebrities.map((c) => c.name)
      const namesToFetch = popularNames.filter((name) => !existingNames.includes(name))

      // Fetch profiles for missing celebrities
      const newProfiles = await Promise.all(
        namesToFetch.slice(0, count - celebrities.length).map((name) => fetchCelebrityProfile(name)),
      )

      // Combine with existing celebrities
      const allCelebrities = [...celebrities, ...newProfiles]

      // Sort by popularity
      allCelebrities.sort((a, b) => b.popularityScore - a.popularityScore)

      return allCelebrities.slice(0, count).map((celebrity) => ({
        id: celebrity._id?.toString() || celebrity.id,
        name: celebrity.name,
        image: celebrity.image,
        age: celebrity.age,
        description: celebrity.description,
        popularityScore: celebrity.popularityScore,
        sentimentScore: celebrity.sentimentScore,
        credibilityScore: celebrity.credibilityScore,
        engagementScore: celebrity.engagementScore,
        recentActivity: celebrity.recentActivity || [],
      }))
    }

    // Map database objects to Celebrity interface
    return celebrities.map((celebrity) => ({
      id: celebrity._id.toString(),
      name: celebrity.name,
      image: celebrity.image,
      age: celebrity.age,
      description: celebrity.description,
      popularityScore: celebrity.popularityScore,
      sentimentScore: celebrity.sentimentScore,
      credibilityScore: celebrity.credibilityScore,
      engagementScore: celebrity.engagementScore,
      recentActivity: celebrity.recentActivity || [],
    }))
  } catch (error) {
    console.error("Error fetching top celebrities:", error)
    throw error
  }
}

// Fetch trending celebrities (those with recent popularity increases)
export async function fetchTrendingCelebrities(count = 6): Promise<Celebrity[]> {
  try {
    const client = await clientPromise
    const db = client.db()

    // Get celebrities from database with recent updates
    const oneWeekAgo = new Date()
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7)

    const celebrities = await db
      .collection("celebrities")
      .find({ updatedAt: { $gte: oneWeekAgo } })
      .sort({ popularityScore: -1 })
      .limit(count)
      .toArray()

    // If we don't have enough trending celebrities, fetch some
    if (celebrities.length < count) {
      const trendingNames = ["Zendaya", "Bad Bunny", "Dwayne Johnson", "Billie Eilish", "Tom Holland", "Ariana Grande"]

      // Filter out names we already have
      const existingNames = celebrities.map((c) => c.name)
      const namesToFetch = trendingNames.filter((name) => !existingNames.includes(name))

      // Fetch profiles for missing celebrities
      const newProfiles = await Promise.all(
        namesToFetch.slice(0, count - celebrities.length).map((name) => fetchCelebrityProfile(name)),
      )

      // Combine with existing celebrities
      const allCelebrities = [...celebrities, ...newProfiles]

      return allCelebrities.slice(0, count).map((celebrity) => ({
        id: celebrity._id?.toString() || celebrity.id,
        name: celebrity.name,
        image: celebrity.image,
        age: celebrity.age,
        description: celebrity.description,
        popularityScore: celebrity.popularityScore,
        sentimentScore: celebrity.sentimentScore,
        credibilityScore: celebrity.credibilityScore,
        engagementScore: celebrity.engagementScore,
        recentActivity: celebrity.recentActivity || [],
      }))
    }

    // Map database objects to Celebrity interface
    return celebrities.map((celebrity) => ({
      id: celebrity._id.toString(),
      name: celebrity.name,
      image: celebrity.image,
      age: celebrity.age,
      description: celebrity.description,
      popularityScore: celebrity.popularityScore,
      sentimentScore: celebrity.sentimentScore,
      credibilityScore: celebrity.credibilityScore,
      engagementScore: celebrity.engagementScore,
      recentActivity: celebrity.recentActivity || [],
    }))
  } catch (error) {
    console.error("Error fetching trending celebrities:", error)
    throw error
  }
}

// Search for celebrities by name
export async function searchCelebrities(query: string): Promise<Celebrity[]> {
  try {
    if (!query) {
      return await fetchTopCelebrities(6)
    }

    const client = await clientPromise
    const db = client.db()

    // Search for celebrities in database
    const celebrities = await db
      .collection("celebrities")
      .find({
        $or: [{ name: { $regex: query, $options: "i" } }, { description: { $regex: query, $options: "i" } }],
      })
      .limit(10)
      .toArray()

    // If we found celebrities, return them
    if (celebrities.length > 0) {
      return celebrities.map((celebrity) => ({
        id: celebrity._id.toString(),
        name: celebrity.name,
        image: celebrity.image,
        age: celebrity.age,
        description: celebrity.description,
        popularityScore: celebrity.popularityScore,
        sentimentScore: celebrity.sentimentScore,
        credibilityScore: celebrity.credibilityScore,
        engagementScore: celebrity.engagementScore,
        recentActivity: celebrity.recentActivity || [],
      }))
    }

    // If no results in database, try to fetch the celebrity
    try {
      const celebrity = await fetchCelebrityProfile(query)
      return [celebrity]
    } catch (fetchError) {
      console.error("Error fetching celebrity in search:", fetchError)
      return []
    }
  } catch (error) {
    console.error("Error searching celebrities:", error)
    throw error
  }
}

// Get reviews for a celebrity
export async function getCelebrityReviews(celebrityId: string): Promise<Review[]> {
  try {
    const client = await clientPromise
    const db = client.db()

    // Get reviews from database
    const reviews = await db.collection("reviews").find({ celebrityId }).sort({ date: -1 }).toArray()

    // Get user info for each review
    const reviewsWithUserInfo = await Promise.all(
      reviews.map(async (review) => {
        let userName = "Anonymous"
        let userImage = null

        try {
          const user = await db.collection("users").findOne({ _id: new ObjectId(review.userId) })
          if (user) {
            userName = user.name
            userImage = user.image
          }
        } catch (userError) {
          console.error("Error fetching user for review:", userError)
        }

        return {
          id: review._id.toString(),
          celebrityId: review.celebrityId,
          userId: review.userId,
          userName,
          userImage,
          content: review.content,
          rating: review.rating,
          date: review.date,
          upvotes: review.upvotes,
          downvotes: review.downvotes,
        }
      }),
    )

    return reviewsWithUserInfo
  } catch (error) {
    console.error("Error getting celebrity reviews:", error)
    return []
  }
}

// Add a review for a celebrity
export async function addCelebrityReview(review: {
  celebrityId: string
  userId: string
  content: string
  rating: number
}): Promise<Review> {
  try {
    const client = await clientPromise
    const db = client.db()

    // Create review
    const newReview = {
      celebrityId: review.celebrityId,
      userId: review.userId,
      content: review.content,
      rating: review.rating,
      date: new Date().toISOString(),
      upvotes: 0,
      downvotes: 0,
    }

    const result = await db.collection("reviews").insertOne(newReview)

    // Get user info
    let userName = "Anonymous"
    let userImage = null

    try {
      const user = await db.collection("users").findOne({ _id: new ObjectId(review.userId) })
      if (user) {
        userName = user.name
        userImage = user.image
      }
    } catch (userError) {
      console.error("Error fetching user for review:", userError)
    }

    return {
      id: result.insertedId.toString(),
      celebrityId: review.celebrityId,
      userId: review.userId,
      userName,
      userImage,
      content: review.content,
      rating: review.rating,
      date: newReview.date,
      upvotes: 0,
      downvotes: 0,
    }
  } catch (error) {
    console.error("Error adding celebrity review:", error)
    throw error
  }
}

// Vote on a review
export async function voteOnReview(reviewId: string, isUpvote: boolean): Promise<void> {
  try {
    const client = await clientPromise
    const db = client.db()

    const updateField = isUpvote ? "upvotes" : "downvotes"

    await db.collection("reviews").updateOne({ _id: new ObjectId(reviewId) }, { $inc: { [updateField]: 1 } })
  } catch (error) {
    console.error("Error voting on review:", error)
    throw error
  }
}

